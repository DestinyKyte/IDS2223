package it.unicam.cs.ids.loyaltyPlatform;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LoyaltyPlatformApplicationTests {

	@Test
	void contextLoads() {
	}

}
